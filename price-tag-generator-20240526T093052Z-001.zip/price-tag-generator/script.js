// Function to format the price with commas
function formatPriceWithCommas(price) {
    return price.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Function to generate a random barcode number and display it on the page
function generateBarcode() {  
    // Generate a random 12-digit barcode number
    const barcodeNumber = Math.floor(Math.random() * 1000000000000);

    // Set the generated barcode number as text content of the element with id "barcodeNumber"
    document.getElementById("barcodeNumber").textContent = barcodeNumber;

    // Use JsBarcode library to generate a barcode image using the generated barcode number
    const barcodeValue = barcodeNumber;
    JsBarcode("#barcode", barcodeValue, {
        format: "CODE128",      // Use CODE128 format for the barcode
        displayValue: false     // Do not display the barcode value next to it
    });
}

// Function to generate a price tag based on user input
function generatePriceTag() {
    // Get the product name and price entered by the user
    const productName = document.getElementById("productNameInput").value;
    let productPrice = document.getElementById("productPriceInput").value;
    
    // Check if the product price is a valid numeric value without the letter 'E'
    if (!isNaN(productPrice) && !productPrice.includes("E") && !productPrice.includes("-")) {
        // Format the product price with commas
        productPrice = formatPriceWithCommas(productPrice);
        
        // Get elements where the product name and price will be displayed
        const productNameElement = document.getElementById("productName");
        const productPriceElement = document.getElementById("productPrice");

        // Check if both product name and price are provided
        if (productName && productPrice) {
            // Display the product name and price on the price tag
            productNameElement.textContent = productName;
            productPriceElement.textContent = "PHP " + productPrice;

            // Generate and display the barcode for the product
            generateBarcode();

            // Hide the input container and show the result container
            document.querySelector('.input-container').style.display = 'none';
            document.querySelector('.result-container').style.display = '';
        } else {
            // Alert the user if either product name or price is missing
            alert("Please enter correct product name and price or syntax.");
        }
    } else {
        // Alert the user if the product price contains invalid characters
        alert("Please enter a valid numeric price without the letter 'E' or hyphens.");
    }
}


// Function to download the generated price tag as an image
function downloadPriceTag() {
    // Get the container element containing the generated price tag
    const resultContainer = document.querySelector('.result');

    // Use html2canvas library to render the result container as a canvas
    html2canvas(resultContainer, {
        // Callback function triggered after rendering is complete
        onrendered: function(canvas) {
            // Convert the canvas to a data URL representing a PNG image
            const imageData = canvas.toDataURL('image/png');

            // Create a download link for the image
            const downloadLink = document.createElement('a');
            downloadLink.href = imageData;
            downloadLink.download = 'price_tag.png';     // Set the filename for the downloaded image
            downloadLink.click();                        // Simulate a click on the download link to trigger download

            // Remove the download link from the document after download is complete
            downloadLink.remove();
        }
    });
}